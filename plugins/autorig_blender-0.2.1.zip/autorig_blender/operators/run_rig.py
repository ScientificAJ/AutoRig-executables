"""Run rig operator with API-first and offline fallback behavior."""

from __future__ import annotations

import json
import os
import tempfile
import time

try:
    import bpy
except ModuleNotFoundError:  # pragma: no cover
    bpy = None

from ..client.api_client import (
    ApiConfig,
    get_rig_job,
    get_rig_result,
    healthz,
    start_rig_job,
    upload_asset,
)
from ..client.offline_runner import run_offline_stub
from ..importers.rig_importer import attach_experimental_motion_drivers, import_rig_result

if bpy is not None:

    def _find_grease_pencil_object(context):
        obj = context.active_object
        if obj and obj.type in {"GPENCIL", "GREASEPENCIL"}:
            return obj
        for other in context.scene.objects:
            if other.type in {"GPENCIL", "GREASEPENCIL"}:
                return other
        return None

    def _extract_grease_pencil_strokes(context, gp_obj, mesh_obj) -> list[list[list[float]]]:
        if gp_obj is None or mesh_obj is None:
            return []

        inv_mesh = mesh_obj.matrix_world.inverted()
        gp_mw = gp_obj.matrix_world

        strokes_out: list[list[list[float]]] = []
        data = getattr(gp_obj, "data", None)
        layers = getattr(data, "layers", None)
        if not layers:
            return []
        for layer in layers:
            frame = getattr(layer, "active_frame", None)
            if frame is None:
                frames = getattr(layer, "frames", None)
                frame = frames[0] if frames else None
            if frame is None:
                continue
            for stroke in getattr(frame, "strokes", []):
                pts: list[list[float]] = []
                for p in getattr(stroke, "points", []):
                    w = gp_mw @ p.co
                    local = inv_mesh @ w
                    pts.append([float(local.x), float(local.y), float(local.z)])
                if len(pts) >= 2:
                    strokes_out.append(pts)
        return strokes_out

    def _export_mesh_to_obj(context, mesh_obj) -> str:
        path = os.path.join(tempfile.gettempdir(), f"autorig_{mesh_obj.name}.obj")
        # Best-effort: select only mesh_obj for export.
        prev_active = context.view_layer.objects.active
        prev_selected = [o for o in context.selected_objects]
        try:
            bpy.ops.object.select_all(action="DESELECT")
            mesh_obj.select_set(True)
            context.view_layer.objects.active = mesh_obj
            # Blender 4.x
            if hasattr(bpy.ops.wm, "obj_export"):
                bpy.ops.wm.obj_export(filepath=path, export_selected_objects=True)
            else:  # Blender 3.x
                bpy.ops.export_scene.obj(filepath=path, use_selection=True)
        finally:
            bpy.ops.object.select_all(action="DESELECT")
            for o in prev_selected:
                try:
                    o.select_set(True)
                except Exception:
                    pass
            try:
                context.view_layer.objects.active = prev_active
            except Exception:
                pass
        return path

    def _resolve_motion_params_from_result(
        result: dict,
    ) -> tuple[list[float], float, float, float] | None:
        ext = result.get("extensions", {})
        if not isinstance(ext, dict):
            return None

        vp = ext.get("vector_parameters")
        if not isinstance(vp, dict):
            # Fallback to nested extension payloads.
            for key in ("hair", "cloth"):
                sub = ext.get(key, {})
                if isinstance(sub, dict) and isinstance(sub.get("vector_parameters"), dict):
                    vp = sub.get("vector_parameters")
                    break

        if not isinstance(vp, dict):
            return None

        direction = vp.get("direction")
        if not (
            isinstance(direction, (list, tuple))
            and len(direction) == 3
            and all(isinstance(x, (int, float)) for x in direction)
        ):
            return None

        intensity = vp.get("intensity")
        frequency = vp.get("frequency")
        damping = vp.get("damping")
        if not all(isinstance(x, (int, float)) for x in (intensity, frequency, damping)):
            return None

        return (
            [float(direction[0]), float(direction[1]), float(direction[2])],
            float(intensity),
            float(frequency),
            float(damping),
        )

    class AUTORIG_OT_run_rig(bpy.types.Operator):
        bl_idname = "autorig.run_rig"
        bl_label = "Run AutoRig"

        def execute(self, context):  # noqa: D401 - Blender execute API
            prefs = context.preferences.addons["autorig_blender"].preferences
            obj = context.active_object
            mesh_name = obj.name if obj else "<none>"

            if prefs.offline_mode == "on":
                result = run_offline_stub(mesh_name)
                self.report({"INFO"}, f"Offline rig: {result['status']}")
                return {"FINISHED"}

            api_ok = healthz(
                ApiConfig(base_url=prefs.api_url, timeout_sec=prefs.timeout_ms / 1000.0)
            )
            if api_ok:
                mesh_obj = obj if obj and obj.type == "MESH" else None
                if mesh_obj is None:
                    self.report({"ERROR"}, "Select a mesh object to export and rig")
                    return {"CANCELLED"}

                guides = None
                if prefs.rig_mode == "geometric_inference":
                    if not prefs.enable_geometric_experimental:
                        self.report(
                            {"ERROR"},
                            "EXPERIMENTAL geometric mode is not enabled in add-on preferences",
                        )
                        return {"CANCELLED"}

                    gp_obj = _find_grease_pencil_object(context)
                    strokes = _extract_grease_pencil_strokes(context, gp_obj, mesh_obj)
                    if not strokes:
                        self.report(
                            {"ERROR"},
                            "No Grease Pencil strokes found. Create a Grease Pencil object and draw guide strokes.",
                        )
                        return {"CANCELLED"}
                    segments = [{"start": s[0], "end": s[-1]} for s in strokes if len(s) >= 2]
                    guides = {"segments": segments, "strokes": strokes}

                cfg = ApiConfig(base_url=prefs.api_url, timeout_sec=prefs.timeout_ms / 1000.0)
                try:
                    mesh_path = _export_mesh_to_obj(context, mesh_obj)
                    asset_id = upload_asset(cfg, mesh_path)

                    experimental_enabled = bool(
                        prefs.enable_hair_rigging_experimental
                        or prefs.enable_cloth_assist_experimental
                    )
                    film_enabled = bool(prefs.enable_film_extension_experimental)
                    motion_preset = prefs.motion_preset_id.strip() or None
                    motion_dir = list(getattr(prefs, "motion_direction", (0.0, 1.0, 0.0)))
                    calibration_raw = str(
                        getattr(prefs, "film_facial_calibration_json", "{}") or "{}"
                    )
                    try:
                        calibration_overrides = json.loads(calibration_raw)
                        if not isinstance(calibration_overrides, dict):
                            calibration_overrides = {}
                    except Exception:
                        calibration_overrides = {}
                    pose_params_raw = str(getattr(prefs, "contact_pose_params_json", "{}") or "{}")
                    try:
                        pose_params = json.loads(pose_params_raw)
                        if not isinstance(pose_params, dict):
                            pose_params = {}
                    except Exception:
                        pose_params = {}

                    pose_mode = str(getattr(prefs, "pose_mode", "auto") or "auto")
                    pose_id = str(getattr(prefs, "contact_pose_id", "") or "").strip()
                    pose_side = str(getattr(prefs, "contact_pose_side", "auto") or "auto")

                    options_payload = {
                        "max_influences": 4,
                        "weight_smoothing": 0.3,
                        "experimental": {
                            "hair_rigging": bool(prefs.enable_hair_rigging_experimental),
                            "cloth_assist": bool(prefs.enable_cloth_assist_experimental),
                            "preset": motion_preset,
                            "vector_parameters": {
                                "direction": motion_dir,
                                "intensity": float(prefs.motion_intensity),
                                "frequency": float(prefs.motion_frequency),
                                "damping": float(prefs.motion_damping),
                            },
                        }
                        if experimental_enabled
                        else {
                            "hair_rigging": False,
                            "cloth_assist": False,
                            "preset": None,
                            "vector_parameters": {},
                        },
                        "film_extension": {
                            "enabled": bool(film_enabled),
                            "facial_plugin_enabled": bool(
                                prefs.enable_film_facial_plugin_experimental
                            ),
                            "facial_plugin": {
                                "enabled": bool(prefs.enable_film_facial_plugin_experimental),
                                "mode": str(getattr(prefs, "film_facial_mode", "auto")),
                                "calibration_overrides": calibration_overrides,
                            },
                        }
                        if film_enabled
                        else {
                            "enabled": False,
                            "facial_plugin_enabled": False,
                            "facial_plugin": {"enabled": False, "mode": "auto"},
                        },
                        "pose_mode": pose_mode,
                        "pose_request": {
                            "pose": pose_id or None,
                            "side": pose_side,
                            "intensity": float(getattr(prefs, "contact_pose_intensity", 1.0)),
                            "damping": float(getattr(prefs, "contact_pose_damping", 0.5)),
                            "falloff": float(getattr(prefs, "contact_pose_falloff", 1.0)),
                            "params": pose_params,
                            "stack": [],
                            "batch_preload": [],
                        },
                    }

                    job_id = start_rig_job(
                        cfg,
                        {
                            "asset_id": asset_id,
                            "rig_template": "l3_68",
                            "target_preset": "blender",
                            "rig_mode": prefs.rig_mode,
                            "guides": guides,
                            "constraints": {
                                "locked_joints": [],
                                "locked_regions": [],
                                "fixed_regions": [],
                            },
                            "options": options_payload,
                        },
                    )

                    t0 = time.time()
                    result_ref = None
                    while time.time() - t0 < 90:
                        state = get_rig_job(cfg, job_id)
                        if state.get("status") == "done" and state.get("result_ref"):
                            result_ref = str(state.get("result_ref"))
                            break
                        if state.get("status") == "failed":
                            self.report({"ERROR"}, "Rig job failed on backend")
                            return {"CANCELLED"}
                        time.sleep(0.25)

                    if not result_ref:
                        self.report({"ERROR"}, "Rig job timed out")
                        return {"CANCELLED"}

                    result = get_rig_result(cfg, result_ref)
                    arm = import_rig_result(context, result, name=f"AutoRig_{mesh_obj.name}")
                    if experimental_enabled:
                        resolved = _resolve_motion_params_from_result(result)
                        if resolved is None:
                            direction = motion_dir
                            intensity = float(prefs.motion_intensity)
                            frequency = float(prefs.motion_frequency)
                            damping = float(prefs.motion_damping)
                        else:
                            direction, intensity, frequency, damping = resolved

                        attach_experimental_motion_drivers(
                            arm,
                            direction=direction,
                            intensity=float(intensity),
                            frequency=float(frequency),
                            damping=float(damping),
                        )

                    self.report(
                        {"INFO"},
                        f"Rig imported: {result_ref} (bones={len(result.get('skeleton', {}).get('joints', []))})",
                    )
                    return {"FINISHED"}
                except Exception as exc:
                    self.report({"ERROR"}, f"Rig failed: {exc}")
                    return {"CANCELLED"}

            if prefs.offline_mode == "auto":
                result = run_offline_stub(mesh_name)
                self.report({"WARNING"}, f"API unavailable, fallback: {result['status']}")
                return {"FINISHED"}

            self.report({"ERROR"}, "API unavailable and offline mode is off")
            return {"CANCELLED"}

    CLASSES = [AUTORIG_OT_run_rig]
else:
    CLASSES = []
