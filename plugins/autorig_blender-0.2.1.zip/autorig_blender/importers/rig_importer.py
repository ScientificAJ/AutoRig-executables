"""Import a rig result payload into Blender as an armature.

This is intentionally minimal: it builds an armature hierarchy from the API skeleton
payload and optionally attaches lightweight procedural drivers to experimental helper bones.
"""

from __future__ import annotations

from typing import Any

try:
    import bpy
except ModuleNotFoundError:  # pragma: no cover
    bpy = None


def _compute_tail(head, child_heads) -> tuple[float, float, float]:
    if child_heads:
        avg = [0.0, 0.0, 0.0]
        for ch in child_heads:
            avg[0] += float(ch[0])
            avg[1] += float(ch[1])
            avg[2] += float(ch[2])
        inv = 1.0 / max(1, len(child_heads))
        avg = (avg[0] * inv, avg[1] * inv, avg[2] * inv)
        dx = avg[0] - float(head[0])
        dy = avg[1] - float(head[1])
        dz = avg[2] - float(head[2])
        if (dx * dx + dy * dy + dz * dz) > 1e-10:
            return avg
    # Fallback: small up-axis tail.
    return (float(head[0]), float(head[1]) + 0.05, float(head[2]))


def _ensure_motion_properties(obj, *, direction, intensity, frequency, damping) -> None:
    obj["autorig_motion_dir_x"] = float(direction[0])
    obj["autorig_motion_dir_y"] = float(direction[1])
    obj["autorig_motion_dir_z"] = float(direction[2])
    obj["autorig_motion_intensity"] = float(intensity)
    obj["autorig_motion_frequency"] = float(frequency)
    obj["autorig_motion_damping"] = float(damping)


def _add_driver(pbone, channel: str, idx: int, *, seg: int, phase: float) -> None:
    # Driver target: pbone.rotation_euler[idx]
    fcurve = pbone.driver_add(channel, idx)
    drv = fcurve.driver
    drv.type = "SCRIPTED"

    var_intensity = drv.variables.new()
    var_intensity.name = "intensity"
    var_intensity.targets[0].id = pbone.id_data  # armature object
    var_intensity.targets[0].data_path = '["autorig_motion_intensity"]'

    var_freq = drv.variables.new()
    var_freq.name = "freq"
    var_freq.targets[0].id = pbone.id_data
    var_freq.targets[0].data_path = '["autorig_motion_frequency"]'

    var_damp = drv.variables.new()
    var_damp.name = "damp"
    var_damp.targets[0].id = pbone.id_data
    var_damp.targets[0].data_path = '["autorig_motion_damping"]'

    var_dir = drv.variables.new()
    var_dir.name = "dirc"
    var_dir.targets[0].id = pbone.id_data
    var_dir.targets[0].data_path = (
        '["autorig_motion_dir_x"]'
        if idx == 0
        else '["autorig_motion_dir_y"]'
        if idx == 1
        else '["autorig_motion_dir_z"]'
    )

    # Note: 'frame' is a built-in driver variable.
    # 0.05 is an arbitrary scale to keep motion subtle; presets control freq/intensity.
    drv.expression = (
        f"sin(frame * freq * 0.05 + {phase:.4f}) * intensity * pow((1.0 - damp), {int(seg)}) * dirc"
    )


def attach_experimental_motion_drivers(
    armature_obj, *, direction, intensity, frequency, damping
) -> None:
    """Attach lightweight drivers to hair/cloth helper bones when present."""

    if bpy is None:  # pragma: no cover
        return

    _ensure_motion_properties(
        armature_obj,
        direction=direction,
        intensity=intensity,
        frequency=frequency,
        damping=damping,
    )

    pose = armature_obj.pose
    if pose is None:
        return

    for name, pbone in pose.bones.items():
        if not (name.startswith("hair_grp_") or name.startswith("cloth_grp_")):
            continue
        parts = name.split("_")
        seg = 0
        if len(parts) >= 4:
            try:
                seg = int(parts[-1])
            except Exception:
                seg = 0
        phase = float(seg) * 0.35
        try:
            pbone.rotation_mode = "XYZ"
        except Exception:
            pass

        for axis in range(3):
            try:
                _add_driver(pbone, "rotation_euler", axis, seg=seg, phase=phase)
            except Exception:
                # Some Blender versions/operators may disallow driver creation in this context.
                continue


def import_rig_result(context, result: dict[str, Any], *, name: str = "AutoRigArmature"):
    """Create an armature object from API rig result and return it."""

    if bpy is None:  # pragma: no cover
        raise RuntimeError("Blender bpy module unavailable")

    skel = result.get("skeleton", {})
    joints = skel.get("joints", [])
    if not isinstance(joints, list) or not joints:
        raise ValueError("Rig result missing skeleton joints")

    # Build joint lookup maps.
    joint_by_id: dict[str, dict[str, Any]] = {}
    children: dict[str, list[str]] = {}
    for j in joints:
        if not isinstance(j, dict):
            continue
        jid = str(j.get("id", ""))
        if not jid:
            continue
        joint_by_id[jid] = j
        children.setdefault(jid, [])

    for j in joints:
        if not isinstance(j, dict):
            continue
        jid = str(j.get("id", ""))
        pid = j.get("parent_id")
        if isinstance(pid, str) and pid in children:
            children[pid].append(jid)

    arm_data = bpy.data.armatures.new(name)
    arm_obj = bpy.data.objects.new(name, arm_data)
    context.collection.objects.link(arm_obj)

    context.view_layer.objects.active = arm_obj
    arm_obj.select_set(True)
    bpy.ops.object.mode_set(mode="EDIT")

    # Create all bones first.
    for jid, j in joint_by_id.items():
        bone = arm_data.edit_bones.new(jid)
        pos = j.get("position", [0.0, 0.0, 0.0])
        bone.head = (float(pos[0]), float(pos[1]), float(pos[2]))
        bone.tail = (float(pos[0]), float(pos[1]) + 0.05, float(pos[2]))

    # Assign parents.
    for jid, j in joint_by_id.items():
        pid = j.get("parent_id")
        if isinstance(pid, str) and pid in arm_data.edit_bones:
            arm_data.edit_bones[jid].parent = arm_data.edit_bones[pid]

    # Set tails using child averages when possible.
    for jid, j in joint_by_id.items():
        bone = arm_data.edit_bones[jid]
        ch = children.get(jid, [])
        child_heads = []
        for cid in ch:
            if cid in arm_data.edit_bones:
                child_heads.append(tuple(arm_data.edit_bones[cid].head))
        bone.tail = _compute_tail(bone.head, child_heads)

    bpy.ops.object.mode_set(mode="POSE")
    return arm_obj
