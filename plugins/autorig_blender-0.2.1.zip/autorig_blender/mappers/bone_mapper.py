"""Bone mapping helpers between AutoRig and Blender armatures."""

from __future__ import annotations


def map_bone_name(name: str) -> str:
    return name.strip().lower()
