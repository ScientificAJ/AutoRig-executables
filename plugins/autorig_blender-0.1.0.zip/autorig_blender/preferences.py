"""Addon preferences and runtime settings."""

from __future__ import annotations

try:
    import bpy
except ModuleNotFoundError:  # pragma: no cover - imported in Blender runtime
    bpy = None


if bpy is not None:
    class AutoRigPreferences(bpy.types.AddonPreferences):
        bl_idname = "autorig_blender"

        api_url: bpy.props.StringProperty(  # type: ignore[attr-defined]
            name="API URL",
            default="http://127.0.0.1:8000",
        )
        timeout_ms: bpy.props.IntProperty(  # type: ignore[attr-defined]
            name="Timeout (ms)",
            default=15000,
            min=1000,
            max=120000,
        )
        offline_mode: bpy.props.EnumProperty(  # type: ignore[attr-defined]
            name="Offline Mode",
            items=[
                ("auto", "Auto", "Fallback when API unavailable"),
                ("on", "On", "Always use offline fallback"),
                ("off", "Off", "Require API"),
            ],
            default="auto",
        )

        def draw(self, context):  # noqa: D401 - Blender draw API
            layout = self.layout
            layout.prop(self, "api_url")
            layout.prop(self, "timeout_ms")
            layout.prop(self, "offline_mode")


    CLASSES = [AutoRigPreferences]
else:
    CLASSES = []
