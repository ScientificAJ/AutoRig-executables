"""Single source of truth for Blender add-on versioning."""

VERSION = (0, 2, 3)
VERSION_STR = ".".join(str(part) for part in VERSION)
