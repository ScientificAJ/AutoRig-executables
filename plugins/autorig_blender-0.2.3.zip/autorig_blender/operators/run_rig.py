"""Run rig operator with API-first and offline fallback behavior."""

from __future__ import annotations

import json
import math
import os
import re
import tempfile
import time
from typing import Any

try:
    import bpy
except ModuleNotFoundError:  # pragma: no cover
    bpy = None

from ..client.api_client import (
    ApiConfig,
    get_pose,
    get_rig_job,
    get_rig_result,
    healthz,
    start_rig_job,
    upload_asset,
)
from ..client.offline_runner import run_offline_stub
from ..importers.rig_importer import attach_experimental_motion_drivers, import_rig_result

_HEX_COLOR_RE = re.compile(r"^#[0-9A-Fa-f]{6}$")


def _format_vec3(value: list[float]) -> str:
    return "[" + ", ".join(f"{v:.4f}" for v in value) + "]"


def _as_finite_vec3(value: Any) -> list[float] | None:
    if not isinstance(value, (list, tuple)) or len(value) != 3:
        return None
    out: list[float] = []
    for item in value:
        try:
            num = float(item)
        except Exception:
            return None
        if not math.isfinite(num):
            return None
        out.append(num)
    return out


def _validate_pocket_anchor_payload(
    *,
    side: str,
    has_center: bool,
    center: Any,
    half_extents: Any,
) -> tuple[bool, str | None, list[float] | None, list[float] | None]:
    side_norm = str(side).strip().lower()
    if side_norm not in {"left", "right"}:
        return False, "Pocket anchor side must be left or right.", None, None
    if not has_center:
        return False, "Pocket anchor center must be set before confirmation.", None, None

    center_vec = _as_finite_vec3(center)
    if center_vec is None:
        return False, "Pocket anchor center must be a finite 3D vector.", None, None

    extents_vec = _as_finite_vec3(half_extents)
    if extents_vec is None:
        return False, "Pocket anchor half extents must be a finite 3D vector.", None, None
    if any(v <= 0.0 for v in extents_vec):
        return False, "Pocket anchor half extents must be strictly positive.", None, None

    return True, None, center_vec, extents_vec


def _normalize_hex_color(raw: Any) -> str:
    return str(raw or "").strip().upper()


def _validate_eyelid_color_payload(
    *,
    enabled: bool,
    left_upper: Any,
    left_lower: Any,
    right_upper: Any,
    right_lower: Any,
    opacity: Any,
    color_space: Any,
) -> tuple[bool, str | None, dict[str, Any] | None]:
    config = {
        "enabled": bool(enabled),
        "left_upper": _normalize_hex_color(left_upper),
        "left_lower": _normalize_hex_color(left_lower),
        "right_upper": _normalize_hex_color(right_upper),
        "right_lower": _normalize_hex_color(right_lower),
        "color_space": str(color_space or "srgb").strip().lower(),
    }
    if not config["enabled"]:
        config["opacity"] = 1.0
        config["color_space"] = "srgb"
        return True, None, config

    try:
        config["opacity"] = float(opacity)
    except Exception:
        return False, "Eyelid opacity must be numeric.", None

    if config["color_space"] != "srgb":
        return False, "Eyelid color space must be 'srgb'.", None
    if not math.isfinite(float(config["opacity"])):
        return False, "Eyelid opacity must be finite.", None
    if float(config["opacity"]) < 0.0 or float(config["opacity"]) > 1.0:
        return False, "Eyelid opacity must be in [0,1].", None

    for field_name in ("left_upper", "left_lower", "right_upper", "right_lower"):
        if not _HEX_COLOR_RE.fullmatch(str(config[field_name])):
            return False, f"Eyelid color `{field_name}` must be #RRGGBB.", None

    return True, None, config


def _pose_mode_resolves_contact_v2(
    pose_mode: str,
    *,
    pose_id: str,
    pose_params: dict[str, Any],
) -> bool:
    mode = str(pose_mode or "auto").strip().lower()
    if mode == "legacy":
        return False
    if mode == "contact_v2":
        return True
    return bool(pose_id or pose_params)


def _pose_is_hand_in_pocket(pose_id: str, pose_payload: dict[str, Any] | None = None) -> bool:
    pid = str(pose_id or "").strip().lower()
    if "hand_in_pocket" in pid:
        return True

    contacts = pose_payload.get("contacts", []) if isinstance(pose_payload, dict) else []
    if not isinstance(contacts, list):
        return False
    for contact in contacts:
        if isinstance(contact, str) and contact.strip().lower() == "hand_in_pocket":
            return True
        if isinstance(contact, dict):
            ctype = str(contact.get("type", "")).strip().lower()
            if ctype == "hand_in_pocket":
                return True
    return False


def _pocket_anchor_confirmation_key(
    *,
    pose_mode: str,
    pose_id: str,
    side: str,
    center: list[float],
    half_extents: list[float],
    eyelid_fingerprint: str = "off",
) -> str:
    mode = (
        "contact_v2"
        if _pose_mode_resolves_contact_v2(pose_mode, pose_id=pose_id, pose_params={})
        else "legacy"
    )
    center_key = ",".join(f"{v:.6f}" for v in center)
    extents_key = ",".join(f"{v:.6f}" for v in half_extents)
    return f"{mode}:{pose_id}:{side}:{center_key}:{extents_key}:{eyelid_fingerprint}"


if bpy is not None:

    def _find_grease_pencil_object(context):
        obj = context.active_object
        if obj and obj.type in {"GPENCIL", "GREASEPENCIL"}:
            return obj
        for other in context.scene.objects:
            if other.type in {"GPENCIL", "GREASEPENCIL"}:
                return other
        return None

    def _extract_grease_pencil_strokes(context, gp_obj, mesh_obj) -> list[list[list[float]]]:
        if gp_obj is None or mesh_obj is None:
            return []

        inv_mesh = mesh_obj.matrix_world.inverted()
        gp_mw = gp_obj.matrix_world

        strokes_out: list[list[list[float]]] = []
        data = getattr(gp_obj, "data", None)
        layers = getattr(data, "layers", None)
        if not layers:
            return []
        for layer in layers:
            frame = getattr(layer, "active_frame", None)
            if frame is None:
                frames = getattr(layer, "frames", None)
                frame = frames[0] if frames else None
            if frame is None:
                continue
            for stroke in getattr(frame, "strokes", []):
                pts: list[list[float]] = []
                for p in getattr(stroke, "points", []):
                    w = gp_mw @ p.co
                    local = inv_mesh @ w
                    pts.append([float(local.x), float(local.y), float(local.z)])
                if len(pts) >= 2:
                    strokes_out.append(pts)
        return strokes_out

    def _export_mesh_to_obj(context, mesh_obj) -> str:
        path = os.path.join(tempfile.gettempdir(), f"autorig_{mesh_obj.name}.obj")
        # Best-effort: select only mesh_obj for export.
        prev_active = context.view_layer.objects.active
        prev_selected = [o for o in context.selected_objects]
        try:
            bpy.ops.object.select_all(action="DESELECT")
            mesh_obj.select_set(True)
            context.view_layer.objects.active = mesh_obj
            # Blender 4.x
            if hasattr(bpy.ops.wm, "obj_export"):
                bpy.ops.wm.obj_export(filepath=path, export_selected_objects=True)
            else:  # Blender 3.x
                bpy.ops.export_scene.obj(filepath=path, use_selection=True)
        finally:
            bpy.ops.object.select_all(action="DESELECT")
            for o in prev_selected:
                try:
                    o.select_set(True)
                except Exception:
                    pass
            try:
                context.view_layer.objects.active = prev_active
            except Exception:
                pass
        return path

    def _resolve_motion_params_from_result(
        result: dict,
    ) -> tuple[list[float], float, float, float] | None:
        ext = result.get("extensions", {})
        if not isinstance(ext, dict):
            return None

        vp = ext.get("vector_parameters")
        if not isinstance(vp, dict):
            # Fallback to nested extension payloads.
            for key in ("hair", "cloth"):
                sub = ext.get(key, {})
                if isinstance(sub, dict) and isinstance(sub.get("vector_parameters"), dict):
                    vp = sub.get("vector_parameters")
                    break

        if not isinstance(vp, dict):
            return None

        direction = vp.get("direction")
        if not (
            isinstance(direction, (list, tuple))
            and len(direction) == 3
            and all(isinstance(x, (int, float)) for x in direction)
        ):
            return None

        intensity = vp.get("intensity")
        frequency = vp.get("frequency")
        damping = vp.get("damping")
        if not all(isinstance(x, (int, float)) for x in (intensity, frequency, damping)):
            return None

        return (
            [float(direction[0]), float(direction[1]), float(direction[2])],
            float(intensity),
            float(frequency),
            float(damping),
        )

    class AUTORIG_OT_run_rig(bpy.types.Operator):
        bl_idname = "autorig.run_rig"
        bl_label = "Run AutoRig"

        _confirm_dialog_pending: bpy.props.BoolProperty(  # type: ignore[attr-defined]
            default=False,
            options={"HIDDEN", "SKIP_SAVE"},
        )
        _confirm_context_key: bpy.props.StringProperty(  # type: ignore[attr-defined]
            default="",
            options={"HIDDEN", "SKIP_SAVE"},
        )
        _confirm_side: bpy.props.StringProperty(  # type: ignore[attr-defined]
            default="",
            options={"HIDDEN", "SKIP_SAVE"},
        )
        _confirm_center: bpy.props.StringProperty(  # type: ignore[attr-defined]
            default="",
            options={"HIDDEN", "SKIP_SAVE"},
        )
        _confirm_extents: bpy.props.StringProperty(  # type: ignore[attr-defined]
            default="",
            options={"HIDDEN", "SKIP_SAVE"},
        )
        _confirm_preview: bpy.props.StringProperty(  # type: ignore[attr-defined]
            default="hidden",
            options={"HIDDEN", "SKIP_SAVE"},
        )

        def draw(self, context):  # noqa: D401 - Blender draw API
            del context
            if not self._confirm_dialog_pending:
                return
            layout = self.layout
            layout.label(text="Pocket anchor confirmation is required for this pose.")
            box = layout.box()
            box.label(text=f"side: {self._confirm_side}")
            box.label(text=f"center: {self._confirm_center}")
            box.label(text=f"half_extents: {self._confirm_extents}")
            box.label(text=f"preview: {self._confirm_preview}")
            layout.label(text="Press OK to confirm, or Cancel to reposition.")

        def execute(self, context):  # noqa: D401 - Blender execute API
            prefs = context.preferences.addons["autorig_blender"].preferences
            if self._confirm_dialog_pending:
                prefs.pocket_anchor_confirmed = True
                prefs.pocket_anchor_confirmation_key = str(self._confirm_context_key or "")
                self._confirm_dialog_pending = False
            obj = context.active_object
            mesh_name = obj.name if obj else "<none>"

            if prefs.offline_mode == "on":
                result = run_offline_stub(mesh_name)
                self.report({"INFO"}, f"Offline rig: {result['status']}")
                return {"FINISHED"}

            api_ok = healthz(
                ApiConfig(base_url=prefs.api_url, timeout_sec=prefs.timeout_ms / 1000.0)
            )
            if api_ok:
                mesh_obj = obj if obj and obj.type == "MESH" else None
                if mesh_obj is None:
                    self.report({"ERROR"}, "Select a mesh object to export and rig")
                    return {"CANCELLED"}

                guides = None
                if prefs.rig_mode == "geometric_inference":
                    if not prefs.enable_geometric_experimental:
                        self.report(
                            {"ERROR"},
                            "EXPERIMENTAL geometric mode is not enabled in add-on preferences",
                        )
                        return {"CANCELLED"}

                    gp_obj = _find_grease_pencil_object(context)
                    strokes = _extract_grease_pencil_strokes(context, gp_obj, mesh_obj)
                    if not strokes:
                        self.report(
                            {"ERROR"},
                            "No Grease Pencil strokes found. Create a Grease Pencil object and draw guide strokes.",
                        )
                        return {"CANCELLED"}
                    segments = [{"start": s[0], "end": s[-1]} for s in strokes if len(s) >= 2]
                    guides = {"segments": segments, "strokes": strokes}

                cfg = ApiConfig(base_url=prefs.api_url, timeout_sec=prefs.timeout_ms / 1000.0)
                try:
                    mesh_path = _export_mesh_to_obj(context, mesh_obj)
                    asset_id = upload_asset(cfg, mesh_path)

                    experimental_enabled = bool(
                        prefs.enable_hair_rigging_experimental
                        or prefs.enable_cloth_assist_experimental
                    )
                    film_enabled = bool(prefs.enable_film_extension_experimental)
                    facial_plugin_enabled = bool(prefs.enable_film_facial_plugin_experimental)
                    eyelid_color_enabled = bool(
                        getattr(prefs, "enable_film_eyelid_color_experimental", False)
                    )
                    eyelid_active = bool(
                        film_enabled and facial_plugin_enabled and eyelid_color_enabled
                    )
                    motion_preset = prefs.motion_preset_id.strip() or None
                    motion_dir = list(getattr(prefs, "motion_direction", (0.0, 1.0, 0.0)))
                    calibration_raw = str(
                        getattr(prefs, "film_facial_calibration_json", "{}") or "{}"
                    )
                    try:
                        calibration_overrides = json.loads(calibration_raw)
                        if not isinstance(calibration_overrides, dict):
                            calibration_overrides = {}
                    except Exception:
                        calibration_overrides = {}
                    valid_eyelid, eyelid_error, eyelid_payload = _validate_eyelid_color_payload(
                        enabled=eyelid_active,
                        left_upper=getattr(prefs, "film_eyelid_left_upper", "#000000"),
                        left_lower=getattr(prefs, "film_eyelid_left_lower", "#000000"),
                        right_upper=getattr(prefs, "film_eyelid_right_upper", "#000000"),
                        right_lower=getattr(prefs, "film_eyelid_right_lower", "#000000"),
                        opacity=getattr(prefs, "film_eyelid_opacity", 1.0),
                        color_space=getattr(prefs, "film_eyelid_color_space", "srgb"),
                    )
                    if not valid_eyelid or eyelid_payload is None:
                        self.report({"ERROR"}, eyelid_error or "Invalid eyelid color configuration")
                        return {"CANCELLED"}
                    eyelid_fingerprint = "off"
                    if eyelid_active:
                        eyelid_fingerprint = "|".join(
                            [
                                str(eyelid_payload["left_upper"]),
                                str(eyelid_payload["left_lower"]),
                                str(eyelid_payload["right_upper"]),
                                str(eyelid_payload["right_lower"]),
                                f"{float(eyelid_payload['opacity']):.4f}",
                                str(eyelid_payload["color_space"]),
                            ]
                        )
                    pose_params_raw = str(getattr(prefs, "contact_pose_params_json", "{}") or "{}")
                    try:
                        pose_params = json.loads(pose_params_raw)
                        if not isinstance(pose_params, dict):
                            pose_params = {}
                    except Exception:
                        pose_params = {}

                    pose_mode = str(getattr(prefs, "pose_mode", "auto") or "auto")
                    pose_id = str(getattr(prefs, "contact_pose_id", "") or "").strip()
                    pose_side = str(getattr(prefs, "contact_pose_side", "auto") or "auto")
                    if pose_side not in {"left", "right", "auto"}:
                        pose_side = "auto"

                    pose_mode_contact = _pose_mode_resolves_contact_v2(
                        pose_mode,
                        pose_id=pose_id,
                        pose_params=pose_params,
                    )
                    pose_payload = None
                    if pose_id:
                        try:
                            pose_payload = get_pose(cfg, pose_id)
                        except Exception:
                            pose_payload = None
                    pocket_pose_selected = _pose_is_hand_in_pocket(pose_id, pose_payload)
                    pocket_gate_required = bool(pose_mode_contact and pocket_pose_selected)

                    anchor_side = str(getattr(prefs, "pocket_anchor_side", "left") or "left")
                    anchor_has_center = bool(getattr(prefs, "pocket_anchor_has_center", False))
                    anchor_center_raw = list(
                        getattr(prefs, "pocket_anchor_center", (0.0, 0.0, 0.0))
                    )
                    anchor_half_extents_raw = list(
                        getattr(prefs, "pocket_anchor_half_extents", (0.06, 0.08, 0.05))
                    )
                    anchor_preview_enabled = bool(
                        getattr(prefs, "pocket_anchor_preview_enabled", True)
                    )
                    valid_anchor, anchor_error, anchor_center, anchor_half_extents = (
                        _validate_pocket_anchor_payload(
                            side=anchor_side,
                            has_center=anchor_has_center,
                            center=anchor_center_raw,
                            half_extents=anchor_half_extents_raw,
                        )
                    )

                    if pocket_gate_required:
                        if not valid_anchor or anchor_center is None or anchor_half_extents is None:
                            prefs.pocket_anchor_confirmed = False
                            prefs.pocket_anchor_confirmation_key = ""
                            self.report({"ERROR"}, anchor_error or "Invalid pocket anchor marker")
                            return {"CANCELLED"}

                        context_key = _pocket_anchor_confirmation_key(
                            pose_mode=pose_mode,
                            pose_id=pose_id,
                            side=anchor_side,
                            center=anchor_center,
                            half_extents=anchor_half_extents,
                            eyelid_fingerprint=eyelid_fingerprint,
                        )
                        if (
                            not bool(getattr(prefs, "pocket_anchor_confirmed", False))
                            or str(getattr(prefs, "pocket_anchor_confirmation_key", "") or "")
                            != context_key
                        ):
                            self._confirm_dialog_pending = True
                            self._confirm_context_key = context_key
                            self._confirm_side = anchor_side
                            self._confirm_center = _format_vec3(anchor_center)
                            self._confirm_extents = _format_vec3(anchor_half_extents)
                            self._confirm_preview = (
                                "visible" if anchor_preview_enabled else "hidden"
                            )
                            return context.window_manager.invoke_props_dialog(self, width=420)

                        marker_root_raw = pose_params.get("pocket_anchor_markers")
                        marker_root = (
                            dict(marker_root_raw) if isinstance(marker_root_raw, dict) else {}
                        )
                        marker_root[anchor_side] = {
                            "center": anchor_center,
                            "half_extents": anchor_half_extents,
                        }
                        pose_params["pocket_anchor_markers"] = marker_root
                        pose_side = anchor_side
                    else:
                        prefs.pocket_anchor_confirmed = False
                        prefs.pocket_anchor_confirmation_key = ""

                    options_payload = {
                        "max_influences": 4,
                        "weight_smoothing": 0.3,
                        "experimental": {
                            "hair_rigging": bool(prefs.enable_hair_rigging_experimental),
                            "cloth_assist": bool(prefs.enable_cloth_assist_experimental),
                            "preset": motion_preset,
                            "vector_parameters": {
                                "direction": motion_dir,
                                "intensity": float(prefs.motion_intensity),
                                "frequency": float(prefs.motion_frequency),
                                "damping": float(prefs.motion_damping),
                            },
                        }
                        if experimental_enabled
                        else {
                            "hair_rigging": False,
                            "cloth_assist": False,
                            "preset": None,
                            "vector_parameters": {},
                        },
                        "film_extension": {
                            "enabled": bool(film_enabled),
                            "facial_plugin_enabled": bool(facial_plugin_enabled),
                            "facial_plugin": {
                                "enabled": bool(facial_plugin_enabled),
                                "mode": str(getattr(prefs, "film_facial_mode", "auto")),
                                "calibration_overrides": calibration_overrides,
                                "appearance": {"eyelid_color": eyelid_payload},
                            },
                        }
                        if film_enabled
                        else {
                            "enabled": False,
                            "facial_plugin_enabled": False,
                            "facial_plugin": {
                                "enabled": False,
                                "mode": "auto",
                                "appearance": {
                                    "eyelid_color": {
                                        "enabled": False,
                                        "left_upper": "#000000",
                                        "left_lower": "#000000",
                                        "right_upper": "#000000",
                                        "right_lower": "#000000",
                                        "opacity": 1.0,
                                        "color_space": "srgb",
                                    }
                                },
                            },
                        },
                        "pose_mode": pose_mode,
                        "pose_request": {
                            "pose": pose_id or None,
                            "side": pose_side,
                            "intensity": float(getattr(prefs, "contact_pose_intensity", 1.0)),
                            "damping": float(getattr(prefs, "contact_pose_damping", 0.5)),
                            "falloff": float(getattr(prefs, "contact_pose_falloff", 1.0)),
                            "params": pose_params,
                            "stack": [],
                            "batch_preload": [],
                        },
                    }

                    job_id = start_rig_job(
                        cfg,
                        {
                            "asset_id": asset_id,
                            "rig_template": "l3_68",
                            "target_preset": "blender",
                            "rig_mode": prefs.rig_mode,
                            "guides": guides,
                            "constraints": {
                                "locked_joints": [],
                                "locked_regions": [],
                                "fixed_regions": [],
                            },
                            "options": options_payload,
                        },
                    )

                    t0 = time.time()
                    result_ref = None
                    while time.time() - t0 < 90:
                        state = get_rig_job(cfg, job_id)
                        if state.get("status") == "done" and state.get("result_ref"):
                            result_ref = str(state.get("result_ref"))
                            break
                        if state.get("status") == "failed":
                            self.report({"ERROR"}, "Rig job failed on backend")
                            return {"CANCELLED"}
                        time.sleep(0.25)

                    if not result_ref:
                        self.report({"ERROR"}, "Rig job timed out")
                        return {"CANCELLED"}

                    result = get_rig_result(cfg, result_ref)
                    arm = import_rig_result(context, result, name=f"AutoRig_{mesh_obj.name}")
                    if experimental_enabled:
                        resolved = _resolve_motion_params_from_result(result)
                        if resolved is None:
                            direction = motion_dir
                            intensity = float(prefs.motion_intensity)
                            frequency = float(prefs.motion_frequency)
                            damping = float(prefs.motion_damping)
                        else:
                            direction, intensity, frequency, damping = resolved

                        attach_experimental_motion_drivers(
                            arm,
                            direction=direction,
                            intensity=float(intensity),
                            frequency=float(frequency),
                            damping=float(damping),
                        )

                    self.report(
                        {"INFO"},
                        f"Rig imported: {result_ref} (bones={len(result.get('skeleton', {}).get('joints', []))})",
                    )
                    return {"FINISHED"}
                except Exception as exc:
                    self.report({"ERROR"}, f"Rig failed: {exc}")
                    return {"CANCELLED"}

            if prefs.offline_mode == "auto":
                result = run_offline_stub(mesh_name)
                self.report({"WARNING"}, f"API unavailable, fallback: {result['status']}")
                return {"FINISHED"}

            self.report({"ERROR"}, "API unavailable and offline mode is off")
            return {"CANCELLED"}

    CLASSES = [AUTORIG_OT_run_rig]
else:
    CLASSES = []
