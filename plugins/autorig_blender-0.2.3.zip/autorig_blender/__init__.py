"""AutoRig AI Blender add-on entrypoint."""

from __future__ import annotations

from .addon_info import VERSION
from .operators import export_result, health_check, run_rig
from .panels import diagnostics_panel, main_panel
from .preferences import CLASSES as PREF_CLASSES

try:
    import bpy
except ModuleNotFoundError:  # pragma: no cover
    bpy = None

bl_info = {
    "name": "AutoRig AI",
    "author": "AutoRig AI",
    "version": VERSION,
    "blender": (3, 6, 0),
    "location": "View3D > Sidebar > AutoRig AI",
    "description": "Neural auto-rigging with API-first workflow and offline fallback",
    "category": "Rigging",
}

CLASSES = [
    *PREF_CLASSES,
    *health_check.CLASSES,
    *run_rig.CLASSES,
    *export_result.CLASSES,
    *main_panel.CLASSES,
    *diagnostics_panel.CLASSES,
]


def register() -> None:
    if bpy is None:  # pragma: no cover
        return

    for cls in CLASSES:
        bpy.utils.register_class(cls)

    bpy.types.Scene.autorig_last_health = bpy.props.StringProperty(  # type: ignore[attr-defined]
        name="AutoRig Last Health",
        default="unknown",
    )


def unregister() -> None:
    if bpy is None:  # pragma: no cover
        return

    if hasattr(bpy.types.Scene, "autorig_last_health"):
        del bpy.types.Scene.autorig_last_health

    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
