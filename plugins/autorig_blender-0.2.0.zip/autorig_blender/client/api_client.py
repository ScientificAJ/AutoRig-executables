"""HTTP client for API-first Blender execution."""

from __future__ import annotations

import json
import mimetypes
import os
import urllib.error
import urllib.request
import uuid
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class ApiConfig:
    base_url: str = "http://127.0.0.1:8000"
    timeout_sec: float = 15.0


def _json_fetch(
    config: ApiConfig, path: str, *, method: str = "GET", payload: Any | None = None
) -> Any:
    url = f"{config.base_url}{path}"
    data = None
    headers: dict[str, str] = {}
    if payload is not None:
        data = json.dumps(payload).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    with urllib.request.urlopen(req, timeout=config.timeout_sec) as res:
        return json.loads(res.read().decode("utf-8"))


def _encode_multipart_file(field_name: str, file_path: str) -> tuple[bytes, str]:
    boundary = f"----autorigboundary{uuid.uuid4().hex}"
    filename = os.path.basename(file_path)
    ctype = mimetypes.guess_type(filename)[0] or "application/octet-stream"
    file_bytes = open(file_path, "rb").read()

    lines: list[bytes] = []
    lines.append(f"--{boundary}\r\n".encode("utf-8"))
    lines.append(
        f'Content-Disposition: form-data; name="{field_name}"; filename="{filename}"\r\n'.encode(
            "utf-8"
        )
    )
    lines.append(f"Content-Type: {ctype}\r\n\r\n".encode("utf-8"))
    lines.append(file_bytes)
    lines.append(b"\r\n")
    lines.append(f"--{boundary}--\r\n".encode("utf-8"))
    body = b"".join(lines)
    content_type = f"multipart/form-data; boundary={boundary}"
    return body, content_type


def healthz(config: ApiConfig) -> bool:
    try:
        req = urllib.request.Request(f"{config.base_url}/healthz", method="GET")
        with urllib.request.urlopen(req, timeout=config.timeout_sec) as res:
            payload = json.loads(res.read().decode("utf-8"))
            return payload.get("status") == "ok"
    except (ValueError, urllib.error.URLError, TimeoutError, json.JSONDecodeError):
        return False


def upload_asset(config: ApiConfig, file_path: str) -> str:
    body, content_type = _encode_multipart_file("file", file_path)
    req = urllib.request.Request(
        f"{config.base_url}/v1/assets/upload",
        data=body,
        headers={"Content-Type": content_type},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=config.timeout_sec) as res:
        payload = json.loads(res.read().decode("utf-8"))
    asset_id = payload.get("asset_id")
    if not isinstance(asset_id, str):
        raise ValueError("upload response missing asset_id")
    return asset_id


def start_rig_job(config: ApiConfig, payload: dict[str, Any]) -> str:
    res = _json_fetch(config, "/v1/rig-jobs", method="POST", payload=payload)
    job_id = res.get("job_id")
    if not isinstance(job_id, str):
        raise ValueError("rig job response missing job_id")
    return job_id


def get_rig_job(config: ApiConfig, job_id: str) -> dict[str, Any]:
    res = _json_fetch(config, f"/v1/rig-jobs/{job_id}", method="GET")
    if not isinstance(res, dict):
        raise ValueError("rig job response must be an object")
    return res


def get_rig_result(config: ApiConfig, result_id: str) -> dict[str, Any]:
    res = _json_fetch(config, f"/v1/rig-results/{result_id}", method="GET")
    if not isinstance(res, dict):
        raise ValueError("rig result response must be an object")
    return res
