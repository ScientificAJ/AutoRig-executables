"""Addon preferences and runtime settings."""

from __future__ import annotations

try:
    import bpy
except ModuleNotFoundError:  # pragma: no cover - imported in Blender runtime
    bpy = None


if bpy is not None:

    class AutoRigPreferences(bpy.types.AddonPreferences):
        bl_idname = "autorig_blender"

        api_url: bpy.props.StringProperty(  # type: ignore[attr-defined]
            name="API URL",
            default="http://127.0.0.1:8000",
        )
        timeout_ms: bpy.props.IntProperty(  # type: ignore[attr-defined]
            name="Timeout (ms)",
            default=15000,
            min=1000,
            max=120000,
        )
        offline_mode: bpy.props.EnumProperty(  # type: ignore[attr-defined]
            name="Offline Mode",
            items=[
                ("auto", "Auto", "Fallback when API unavailable"),
                ("on", "On", "Always use offline fallback"),
                ("off", "Off", "Require API"),
            ],
            default="auto",
        )
        enable_geometric_experimental: bpy.props.BoolProperty(  # type: ignore[attr-defined]
            name="Enable EXPERIMENTAL Geometric Inference",
            default=False,
            description="Allows EXPERIMENTAL Draw -> Recognize -> Correct geometric inference mode.",
        )
        enable_hair_rigging_experimental: bpy.props.BoolProperty(  # type: ignore[attr-defined]
            name="Enable EXPERIMENTAL Hair Rigging",
            default=False,
            description="Generate experimental hair helper bones (hair_grp_*).",
        )
        enable_cloth_assist_experimental: bpy.props.BoolProperty(  # type: ignore[attr-defined]
            name="Enable EXPERIMENTAL Cloth Assist",
            default=False,
            description="Generate experimental cloth helper bones (cloth_grp_*).",
        )
        motion_preset_id: bpy.props.StringProperty(  # type: ignore[attr-defined]
            name="Motion Preset ID",
            default="",
            description="Optional motion preset ID served by the API (e.g., Wind_001).",
        )
        motion_direction: bpy.props.FloatVectorProperty(  # type: ignore[attr-defined]
            name="Direction",
            size=3,
            default=(0.0, 1.0, 0.0),
            description="Override motion direction vector (x,y,z).",
        )
        motion_intensity: bpy.props.FloatProperty(  # type: ignore[attr-defined]
            name="Intensity",
            default=0.3,
            min=0.0,
            max=2.0,
        )
        motion_frequency: bpy.props.FloatProperty(  # type: ignore[attr-defined]
            name="Frequency",
            default=0.8,
            min=0.0,
            max=5.0,
        )
        motion_damping: bpy.props.FloatProperty(  # type: ignore[attr-defined]
            name="Damping",
            default=0.5,
            min=0.0,
            max=1.0,
        )
        rig_mode: bpy.props.EnumProperty(  # type: ignore[attr-defined]
            name="Rig Mode",
            items=[
                ("ml", "ML (Default)", "Default ML/template pipeline"),
                (
                    "geometric_inference",
                    "Geometric Inference (EXPERIMENTAL)",
                    "Use guide strokes/lines to infer skeleton before correction/export",
                ),
            ],
            default="ml",
        )

        def draw(self, context):  # noqa: D401 - Blender draw API
            layout = self.layout
            layout.prop(self, "api_url")
            layout.prop(self, "timeout_ms")
            layout.prop(self, "offline_mode")
            layout.separator()
            layout.label(text="Experimental", icon="ERROR")
            layout.prop(self, "enable_geometric_experimental")
            layout.prop(self, "enable_hair_rigging_experimental")
            layout.prop(self, "enable_cloth_assist_experimental")
            layout.prop(self, "motion_preset_id")
            col = layout.column(align=True)
            col.prop(self, "motion_direction")
            col.prop(self, "motion_intensity")
            col.prop(self, "motion_frequency")
            col.prop(self, "motion_damping")
            layout.prop(self, "rig_mode")

    CLASSES = [AutoRigPreferences]
else:
    CLASSES = []
